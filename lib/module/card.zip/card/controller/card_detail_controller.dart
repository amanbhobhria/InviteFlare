import 'package:invite_flare/export.dart';

class CardDetailController extends GetxController{}