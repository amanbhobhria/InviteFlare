import 'package:injectable/injectable.dart';
import 'package:invite_flare/core/core.dart';

@injectable
class FacebookSignInUseCase extends UseCase<int, NoParams> {
  @override
  Future<int> call(NoParams params) {
    // TODO: implement call
    throw UnimplementedError();
  }
}
