// dart format width=80
// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// InjectableConfigGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:get_it/get_it.dart' as _i174;
import 'package:http/http.dart' as _i519;
import 'package:injectable/injectable.dart' as _i526;

import '../../app/navigation/app_router.dart' as _i481;
import '../../features/card_details/presentation/blocs/card_details_bloc/card_details_bloc.dart'
    as _i434;
import '../../features/cards_display/domain/domain.dart' as _i1068;
import '../../features/cards_display/domain/use_cases/invitation_cards_use_case.dart'
    as _i527;
import '../../features/cards_display/domain/use_cases/subcategories_and_filter_use_case.dart'
    as _i38;
import '../../features/cards_display/presentation/blocs/cards_display_bloc/cards_display_bloc.dart'
    as _i320;
import '../../features/cards_display/presentation/blocs/invitation_cards_bloc/invitation_cards_bloc.dart'
    as _i824;
import '../../features/event_details/domain/use_cases/event_details_use_case.dart'
    as _i77;
import '../../features/event_details/event_details.dart' as _i128;
import '../../features/event_details/presentation/blocs/event_details_bloc/event_details_bloc.dart'
    as _i649;
import '../../features/global_search/domain/use_cases/search_invitation_card_use_case.dart'
    as _i364;
import '../../features/global_search/global_search.dart' as _i566;
import '../../features/global_search/presentation/blocs/global_search_bloc/global_search_bloc.dart'
    as _i811;
import '../../features/search/data/repositories/repositories.dart' as _i282;
import '../../features/search/presentation/blocs/recent_search_bloc/recent_search_bloc.dart'
    as _i299;

import '../../shared/domain/domain.dart' as _i525;
import '../../shared/domain/use_cases/social_media_usecase/facebook_sign_in_use_case.dart'
    as _i598;
import '../../shared/domain/use_cases/social_media_usecase/google_sign_in_use_case.dart'
    as _i64;
import '../../shared/presentation/blocs/social_media_bloc/social_media_bloc.dart'
    as _i919;
import '../../shared/presentation/blocs/text_field_bloc/text_field_bloc.dart'
    as _i253;
import '../network/api_handler.dart' as _i783;
import 'app_module.dart' as _i460;

extension GetItInjectableX on _i174.GetIt {
// initializes the registration of main-scope dependencies inside of GetIt
  _i174.GetIt init({
    String? environment,
    _i526.EnvironmentFilter? environmentFilter,
  }) {
    final gh = _i526.GetItHelper(
      this,
      environment,
      environmentFilter,
    );
    final appModule = _$AppModule();
    gh.factory<_i481.AppRouter>(() => _i481.AppRouter());
    gh.factory<_i783.APIHandler>(() => _i783.APIHandler());
  
    gh.factory<_i434.CardDetailsBloc>(() => _i434.CardDetailsBloc());
    gh.factory<_i77.EventDetailsUseCase>(() => _i77.EventDetailsUseCase());
    gh.factory<_i364.SearchInvitationCardUseCase>(
        () => _i364.SearchInvitationCardUseCase());
    gh.factory<_i299.RecentSearchBloc>(() => _i299.RecentSearchBloc());
    gh.factory<_i598.FacebookSignInUseCase>(
        () => _i598.FacebookSignInUseCase());
    gh.factory<_i64.GoogleSignInUseCase>(() => _i64.GoogleSignInUseCase());
    gh.factory<_i253.TextFieldBloc>(() => _i253.TextFieldBloc());
    gh.singleton<String>(() => appModule.baseUrl);
    gh.singleton<_i519.Client>(() => appModule.httpClient);
    gh.factory<_i811.GlobalSearchBloc>(() => _i811.GlobalSearchBloc(
        searchInvitationCardUseCase: gh<_i566.SearchInvitationCardUseCase>()));

 

    gh.factory<_i282.SearchRepository>(
        () => _i282.SearchRepository(apiHandler: gh<_i783.APIHandler>()));

 

    gh.factory<_i649.EventDetailsBloc>(() => _i649.EventDetailsBloc(
        eventDetailsUseCase: gh<_i128.EventDetailsUseCase>()));

    gh.factory<_i919.SocialMediaBloc>(() => _i919.SocialMediaBloc(
          googleSignInUseCase: gh<_i525.GoogleSignInUseCase>(),
          facebookSignInUseCase: gh<_i525.FacebookSignInUseCase>(),
        ));


    return this;
  }
}

class _$AppModule extends _i460.AppModule {}
