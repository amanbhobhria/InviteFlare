// dart format width=80
// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouterGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

part of 'app_router.dart';

/// generated route for
/// [CardDetailsPage]
class CardDetailsRoute extends PageRouteInfo<CardDetailsRouteArgs> {
  CardDetailsRoute({
    Key? key,
    required Data card,
    List<PageRouteInfo>? children,
  }) : super(
         CardDetailsRoute.name,
         args: CardDetailsRouteArgs(key: key, card: card),
         initialChildren: children,
       );

  static const String name = 'CardDetailsRoute';

  static PageInfo page = PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<CardDetailsRouteArgs>();
      return CardDetailsPage(key: args.key, card: args.card);
    },
  );
}

class CardDetailsRouteArgs {
  const CardDetailsRouteArgs({this.key, required this.card});

  final Key? key;

  final Data card;

  @override
  String toString() {
    return 'CardDetailsRouteArgs{key: $key, card: $card}';
  }
}

/// generated route for
/// [CardsDisplayPage]
class CardsDisplayRoute extends PageRouteInfo<CardsDisplayRouteArgs> {
  CardsDisplayRoute({
    Key? key,
    required String pageTitle,
    List<PageRouteInfo>? children,
  }) : super(
         CardsDisplayRoute.name,
         args: CardsDisplayRouteArgs(key: key, pageTitle: pageTitle),
         initialChildren: children,
       );

  static const String name = 'CardsDisplayRoute';

  static PageInfo page = PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<CardsDisplayRouteArgs>();
      return CardsDisplayPage(key: args.key, pageTitle: args.pageTitle);
    },
  );
}

class CardsDisplayRouteArgs {
  const CardsDisplayRouteArgs({this.key, required this.pageTitle});

  final Key? key;

  final String pageTitle;

  @override
  String toString() {
    return 'CardsDisplayRouteArgs{key: $key, pageTitle: $pageTitle}';
  }
}


/// generated route for
/// [EventDetailsPage]
class EventDetailsRoute extends PageRouteInfo<void> {
  const EventDetailsRoute({List<PageRouteInfo>? children})
    : super(EventDetailsRoute.name, initialChildren: children);

  static const String name = 'EventDetailsRoute';

  static PageInfo page = PageInfo(
    name,
    builder: (data) {
      return const EventDetailsPage();
    },
  );
}

/// generated route for
/// [GlobalSearchPage]
class GlobalSearchRoute extends PageRouteInfo<void> {
  const GlobalSearchRoute({List<PageRouteInfo>? children})
    : super(GlobalSearchRoute.name, initialChildren: children);

  static const String name = 'GlobalSearchRoute';

  static PageInfo page = PageInfo(
    name,
    builder: (data) {
      return const GlobalSearchPage();
    },
  );
}





