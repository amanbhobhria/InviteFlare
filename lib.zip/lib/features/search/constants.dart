class Constants {
  Constants._();

  static const String search = 'api/v1/search';
}
