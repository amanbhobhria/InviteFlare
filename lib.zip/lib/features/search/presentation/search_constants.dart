mixin SearchConstants {
  static String get searchTxt => 'Search';
  static String get searchHintTxt => 'Search your event cards';
}
