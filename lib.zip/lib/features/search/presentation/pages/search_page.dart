import 'package:invite_flare/core/base/base.dart';
import 'package:invite_flare/features/search/search.dart';

class SearchPage extends StatelessWidget {
  const SearchPage({super.key});

  @override
  Widget build(BuildContext context) => const SearchWrapper();
}
