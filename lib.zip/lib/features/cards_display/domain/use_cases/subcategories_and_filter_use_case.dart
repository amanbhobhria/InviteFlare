// import 'dart:convert';

// import 'package:injectable/injectable.dart';
// import 'package:invite_flare/core/core.dart';
// import 'package:invite_flare/features/cards_display/domain/domain.dart';
// // import 'package:invite_flare/features/category/data/data.dart';

// @injectable
// class SubcategoriesAndFilterUseCase
//     extends UseCase<SubcategoriesAndFilterEntity, NoParams> {
//   // final CategoryRepository _categoryRepository =
//   //     CategoryRepository(apiHandler: APIHandler());

//   // @override
//   // Future<SubcategoriesAndFilterEntity> call(NoParams params) async {
//   //   final response =
//   //       await _categoryRepository.getCardsByCategory(params.categoryName);

//   //   return SubcategoriesAndFilterEntity.fromJson(jsonDecode(response.body));
//   // }
// }
