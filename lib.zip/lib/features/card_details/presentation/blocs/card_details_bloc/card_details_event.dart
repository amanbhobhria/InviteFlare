part of 'card_details_bloc.dart';

sealed class CardDetailsEvent extends Equatable {
  const CardDetailsEvent();
}
