abstract class TransactionsEvent {}

class LoadTransactions extends TransactionsEvent {}
