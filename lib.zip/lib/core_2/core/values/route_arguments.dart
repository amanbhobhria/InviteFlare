const isDrawer = "isDrawer";
const paramType = "type";
const argQuestionData = 'argQuestionData';
// const argIsEdit = 'argIsEdit';
const argIsCount = 'argIsCount';
const argIsAdd = 'argIsAdd';
const argIndex = 'argIndex';
const argTitle = 'argTitle';
const argTitleId = 'argTitleId';
const argData = 'argData';
const argIsEdit = 'argIsEdit';
const argRandomNumber = 'argRandomNumber';
/*========================================static pages state========================================*/
