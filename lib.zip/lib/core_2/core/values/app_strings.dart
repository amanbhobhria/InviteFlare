/*
 * @copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

//Network

const String strFontRegularWorkSans = "WorkSansRegular";
const String strFontsBoldWorkSans = "WorkSansBold";
const String strFontSemiBoldWorkSans = "WorkSansSemiBold";
const String strFontMediumWorkSans = "WorkSansMedium";

const String strFontRegularPoppins = "poppinsRegular";
const String strFontsBoldPoppins = "poppinsBold";
const String strFontSemiBoldPoppins = "poppinsSemiBold";
const String strFontMediumPoppins = "poppinsMedium";

const String strFontRegularInter = "interRegular";
const String strFontsBoldInter = "interBold";
const String strFontSemiBoldInter = "interSemiBold";
const String strFontMediumInter = "interMedium";

const String stringNewPassword = "New password";
const String stringReEnterNewPassword = "Re-enter new password";

//======================================key String========================================================================================
