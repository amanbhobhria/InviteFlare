/*
 * @copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

const String LOCALKEY_language = 'LOCALKEY_language';
const String LOCALKEY_onboarding = 'LOCALKEY_onboarding';
const String LOCALKEY_token = "LOCALKEY_token";
const String LOCALKEY_bookid = "LOCALKEY_bookid";
const String LOCALKEY_currentLang= "LOCALKEY_currentLang";
const String LOCALKEY_myAccount= "LOCALKEY_myAccount";
